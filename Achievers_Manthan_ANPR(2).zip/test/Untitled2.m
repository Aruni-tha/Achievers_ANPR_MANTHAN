clear all;
close all;
load('stopSignsAndCars.mat')
stopSigns = stopSignsAndCars(:,1:2);
stopSigns.imageFilename = fullfile(toolboxdir('vision'),...
    'visiondata',stopSigns.imageFilename);
acfDetector = trainACFObjectDetector(stopSigns,'NegativeSamplesFactor',2);
img = imread('E:\numberplate\Plate_Images\1.jpg');
[bboxes,scores] = detect(acfDetector,img);
for i = 1:length(scores)
   annotation = sprintf('Confidence = %.1f',scores(i));
   img = insertObjectAnnotation(img,'rectangle',bboxes(i,:),annotation);
end

figure
imshow(img)