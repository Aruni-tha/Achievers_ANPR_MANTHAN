close all;
v = VideoReader('E:\numberplate\Plate_Images\v1.mp4');
video = read(v);

for i=1:5
    imshow(video(:,:,:,i));
    title(['The Car Number is ' final_output])
    img=video(:,:,:,i);
clear bboxes;
clear scores;
clear k;
[bboxes,scores] = detect(acfDetector,img);

k=find(scores==max(scores));

bs=[bboxes(k,1)*0.98,bboxes(k,2)*0.94, bboxes(k,3)*1.7, bboxes(k,4)*2];
   annotation = sprintf('Confidence = %.1f',scores(i));
    img = insertObjectAnnotation(img,'rectangle',bs,annotation);

 imshow(img)

img=imcrop(img,bs);
% fig, imshow(img);
%  end
load imgfildata1;
[~,cc]=size(img);
pics=imresize(img,[300 500]);

if size(pics,3)==3
  pics=rgb2gray(pics);
end
% seq=strel('rectangle',[5,5]);
% a=imerode(pics,seq);
% fig,imshow(a);
% b=imdilate(a,seq);
threshold = graythresh(pics);
pics =~im2bw(pics,threshold);
pics = bwareaopen(pics,40);
% seq = strel('disk',3);
% pics = imclose(pics,seq);
% fig,imshow(pics)
if cc>2000
    picture1=bwareaopen(pics,3500);
else
picture1=bwareaopen(pics,3000);
end
% fig,imshow(picture1)
picture2=pics-picture1;
% fig,imshow(picture2)
picture2=bwareaopen(picture2,200);
% fig,imshow(picture2)

[L,Ne]=bwlabel(picture2);
propied=regionprops(L,'BoundingBox');

% pause(1)
% for n=1:size(propied,1)
%   rectangle('Position',propied(n).BoundingBox,'EdgeColor','g','LineWidth',2)
% end



final_output=[];
t=[];
for n=1:Ne
  [r,c] = find(L==n);
  n1=pics(min(r):max(r),min(c):max(c));
  n1=imresize(n1,[42,24]);
%   imshow(n1)
  pause(0.2)
  x=[ ];

totalLetters=size(imgfile,2);

 for k=1:totalLetters
    
    y=corr2(imgfile{1,k},n1);
    x=[x y];
    
 end
 t=[t max(x)];
 if max(x)>.5
 z=find(x==max(x));
 out=cell2mat(imgfile(2,z));

final_output=[final_output out];
end
end
final_output

%  file = fopen('number_Plate.txt', 'wt');

%     fprintf(file,'%r\n',final_output);
%     fclose(file);                     
%     winopen('number_Plate.txt')

  title(['The Car Number is ' final_output])
    drawnow;  
 
end