clear all;
close all;
load('plate.mat')
% stopSigns=cell(1,2);
t=table(st1,st2);

% stopSigns.imageFilename = fullfile(toolboxdir('vision'),...
%     'visiondata',stopSigns.imageFilename);
acfDetector = trainACFObjectDetector(t,'NegativeSamplesFactor',2);
for j=1:47

    fn=['E:\numberplate\Plate_Images\' num2str(j) '.jpg'];
% [file,path]=uigetfile({'*.jpg;*.bmp;*.png;*.tif'},'Choose an image');
% s=[path,file];
 img=imread(fn);
figure,imshow(img)
[bboxes,scores] = detect(acfDetector,img);

i=find(scores==max(scores));

bs=[bboxes(i,1)*0.88,bboxes(i,2)*0.94, bboxes(i,3)*1.7, bboxes(i,4)*2];
   annotation = sprintf('Confidence = %.1f',scores(i));
   img = insertObjectAnnotation(img,'rectangle',bs,annotation);

imshow(img)

img=imcrop(img,bs);
figure, imshow(img);
 end
